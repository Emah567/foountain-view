# Upload and Display Image

A Pen created on CodePen.io. Original URL: [https://codepen.io/sultanmcdoom/pen/XBOyEx](https://codepen.io/sultanmcdoom/pen/XBOyEx).

